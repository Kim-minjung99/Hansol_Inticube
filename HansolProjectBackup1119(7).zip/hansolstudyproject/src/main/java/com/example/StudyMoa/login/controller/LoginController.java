package com.example.StudyMoa.login.controller;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.annotation.AuthenticationPrincipal;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.example.StudyMoa.common.dto.Category;
import com.example.StudyMoa.common.service.CategoryService;
import com.example.StudyMoa.common.service.StudyService;
import com.example.StudyMoa.login.dto.User;
import com.example.StudyMoa.login.service.LoginUserService;
//import com.example.StudyMoa.login.service.impl.SecurityServiceImpl;



//LoginController : 로그인하여 이동하는 페이지 매핑(2021.10.27 김민정)

@Controller
@RequestMapping("/")
public class LoginController {
	
	

	
	@Autowired //LoginService대신 insertUserSerivce정의
	LoginUserService loginUserService;
	
	@Autowired
	CategoryService categoryService;
	
	
	
	//private final Logger logger = LoggerFactory.getLogger(LoginController.class.getName());			//다음 클래스로 넘어가는 클래스 이름 받아오기
	
	
	
	@GetMapping(value="/login")
	public String login(){
		System.out.println("컨트롤러 실행");
		
		
		return "login";

		
	}
	

	
	
	@GetMapping(value="/join")
//	@RequestMapping(value="/join", method = {RequestMethod.POST})				
	public String JoinPage(Model model, User user) throws Exception{
		
		System.out.println("join페이지로 들어옴");
		System.out.println("join페이지의 user정보 :"+user);
		List<Category> categoryList = categoryService.selectCategoryList();			//카테고리 리스트 조회
		model.addAttribute("categoryList", categoryList);							//카테고리 리스트 모델 객체 add
		
		return "joinPage";
	}
	
	@RequestMapping(value="/joinForm", method = {RequestMethod.GET, RequestMethod.POST})
//	@RequestMapping(value="/joinForm", method = {RequestMethod.POST})
//	@GetMapping(value="/joinForm")
	public String JoinPage(User user,Errors errors,Model model,HttpServletRequest request, HttpServletResponse response) throws Exception{ //joinPage() 파라미터 안의 정의된 객체정보가 담겨져있는 User클래스 객체 user에 대해 입력할 수 있는 정보를 찾고

		
		System.out.println("joinForm페이지로 들어옴");
		System.out.println("joinForm페이지로 들어옴 user정보: "+user);
		
		
		List<Category> categoryList = categoryService.selectCategoryList();			//카테고리 리스트 조회
		model.addAttribute("categoryList", categoryList);							//카테고리 리스트 모델 객체 add
		
		System.out.println("joinForm의 model정보 :"+model);
		
		
		boolean insertResult = loginUserService.insertUser(user);			//문제발생
		System.out.println("회원가입 결과 :"+insertResult);
		
		model.addAttribute("insertResult",insertResult);							//model에 객체를 담아서 jsp단에 정보를 전송하기
		
		if(insertResult == true) {
			
			
			response.setContentType("text/html; charset=UTF-8");					//java단에서 alert출력하기 [2021.11.18] 
			PrintWriter out = response.getWriter();
            out.println("<script> alert('회원가입이 완료되었습니다');</script>");
            out.flush(); 
            
            return "login";


		}else {
			return "insertUserFail";
		}
		
		
		

	}

	@RequestMapping(value="/userIdCheck", method = RequestMethod.POST)		//method를 Post로 하게되면 Get관련 오류발생, ajax는 post로 보내줬는
	@ResponseBody
	public int userIdCheck(@RequestBody HashMap<String,Object> paramData){		//jsp단에서 전송한 데이터를 해쉬맵 형태로 받아온다.
		
		System.out.println("userIdCheck 실행 : "+paramData);
		
		
		int result = loginUserService.userIdCheck(paramData);
		
		
		return result;
	}
	
	
	
	@RequestMapping(value="/findid")
	public String findid(User user){
		
		String userName = user.getUsername();
		String userPhone = user.getUserPhone();
		
		System.out.println(userName);
		System.out.println(userPhone);
		
		return "findId"; // 원래는 loginPage.jsp로 해야되는데 viewResolver를 통해서 생략가능하다. => 생산성 향상 [2021.10.27 김민정]
	
	
	}
	@RequestMapping(value="/findpw")
	public String findpw(User user){
		
		String userName = user.getUsername();
		String userId = user.getUserId();
		
		System.out.println(userName);
		System.out.println(userId);
		
		
		return "findPw"; // 원래는 loginPage.jsp로 해야되는데 viewResolver를 통해서 생략가능하다. => 생산성 향상 [2021.10.27 김민정]
	
	
	}
	
	@RequestMapping(value="/loginErrorPage")
	public String loginerrorpage() {
		
		
		return "errorPage";
	}
	
	@RequestMapping("/accessDenied") 
	public String accessDenied() { 
		return "accessDenied"; 
	}
	
	
	
	
}

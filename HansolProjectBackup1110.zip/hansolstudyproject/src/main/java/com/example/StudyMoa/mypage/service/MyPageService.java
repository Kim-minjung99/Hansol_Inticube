package com.example.StudyMoa.mypage.service;

public class MyPageService {
	

}



package com.example.StudyMoa.review.web;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.catalina.core.ApplicationContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.StudyMoa.common.service.StudyService;
import com.example.StudyMoa.review.service.ReviewService;

@Controller
public class ReviewController {

	@Autowired
	ReviewService reviewService;
	
	@Autowired
	StudyService studyService;
	
	@RequestMapping(value="/insertStudyReview", method = {RequestMethod.POST}, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public boolean insertStudyReview(@RequestBody HashMap<String,Object> reviewParam){
		System.out.println("reviewParam : "+reviewParam);
		/*
		Review review = new Review();													//review 객체 생성
		
		review.setSNo(Integer.parseInt((String)reviewParam.get("sNo")));				//review 객체에 sNo담기
		review.setSrContent((String)reviewParam.get("srContent"));						//review 객체에 srContent 담기
		review.setSrGrade(Integer.parseInt((String)reviewParam.get("srGrade")));		//review 객체에 srGrade 담기
		*/
		boolean result = reviewService.insertStudyReview(reviewParam);						//studyReview insert
		
		boolean endStudy = studyService.updateStudySEndDate(reviewParam); 					//스터디 종료일자 업데이트
		
		return result;
	}
	
	
	
	@RequestMapping(value="/selectStudyReview", method = {RequestMethod.POST}, produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<Map> selectStudyReview(@RequestBody HashMap<String,Object> dataParam, Model model){
		boolean result = true;
		
		Map<String,Object> map = new HashMap<String,Object>();
		
		dataParam.put("userNo", "1");
		
		System.out.println("map 정보: "+map);
		
		List<Map> selectStudyReview = reviewService.selectStudyReview(dataParam);			//스터디 리뷰 조회
		
		model.addAttribute("selectStudyReview", selectStudyReview);
		
		return selectStudyReview;
	} 
}

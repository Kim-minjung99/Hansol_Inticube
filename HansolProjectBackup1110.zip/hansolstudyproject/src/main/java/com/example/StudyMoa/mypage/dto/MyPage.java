package com.example.StudyMoa.mypage.dto;


import java.sql.Date;

public class MyPage {

		
}

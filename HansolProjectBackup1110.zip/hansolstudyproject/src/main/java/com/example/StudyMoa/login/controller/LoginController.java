package com.example.StudyMoa.login.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.annotation.AuthenticationPrincipal;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.example.StudyMoa.login.dto.User;
import com.example.StudyMoa.login.service.LoginUserService;
//import com.example.StudyMoa.login.service.impl.SecurityServiceImpl;
import com.example.StudyMoa.login.service.impl.SecurityAuth.UserPrincipal;


//LoginController : 로그인하여 이동하는 페이지 매핑(2021.10.27 김민정)

@Controller
public class LoginController {
	

	
	@Autowired //LoginService대신 insertUserSerivce정의
	LoginUserService loginUserService;
	
	
	@RequestMapping(value="/login")
	public String LoginPage(HttpServletRequest request, @RequestParam("userId") String userId, @RequestParam("userPwd") String userPwd, @AuthenticationPrincipal UserPrincipal userPrincipal){

		//사용자가 입력한 user 정보 확인
		System.out.println(userId);
		System.out.println(userPwd);
		

		//빈 등록 확인
//		System.out.println("insertUserLogin 빈확인 :"+loginUserService);
//		System.out.println("시큐리티서비스임플 빈확인:"+securityServiceImpl);
//		
//		UserDetails resultUserLoginInfo = securityServiceImpl.loadUserByUsername(userId);
//		System.out.println("사용자 입력 id,pw 조회 여부 : "+resultUserLoginInfo);
//
//		if(resultUserLoginInfo==null) { //로그인 실패시 다시 로그인 창으로 돌아간다.
//			
//			
//			
//			return "errorPage";
//		}
//		
//		else { //로그인 성공시 메인 페이지로 들어갈 수 있다.
//			
//			HttpSession session=request.getSession();
//			
//			if (session==null) {
//				System.out.println("session is false");
//				return "errorPage";
//			}
//			else {
//				System.out.println("session is true");
////				Iterator<? extends GrantedAuthority> iter = userPrincipal.getAuthorities().iterator();
////				while(iter.hasNext()) {
////					GrantedAuthority auth = iter.next();
////					System.out.println(auth.getAuthority());
////				}
////				
		//return "redirect:/mainPage"; //다른사람의 컨트롤러 단으로 들어가게 될때는 redirect:/도메인 주소 로 들어가야 한다.[2021.11.03 김민정]

			//}
			
			
			
		//}
		
		
		
		//loginService.userLoginInfo(userId,userPwd);
		return "loginPage"; // 원래는 loginPage.jsp로 해야되는데 viewResolver를 통해서 생략가능하다. => 생산성 향상 [2021.10.27 김민정]
	}
	
	@RequestMapping(value="/join")
	public String JoinPage(){
		
		return "joinPage";
	}
	
	
	@RequestMapping(value="/joinForm")
	public String JoinPage(@Valid User user, Model model,  Errors errors){ //joinPage() 파라미터 안의 정의된 객체정보가 담겨져있는 User클래스 객체 user에 대해 입력할 수 있는 정보를 찾고
		//사용자 UI에서 입력한 데이터를 해당 모델(model)에 담아서 정보를 찍어준다. [2021.10.29 김민정]
		
		System.out.println("insert폼 : "+user);

		boolean result = loginUserService.insertUser(user);			//https://www.youtube.com/watch?v=0JHIME7uGOk
		System.out.println("result 결과 : "+ result);
		
		
		//사용자 전화번호 확인해서 동일하면 메인페이지로 넘기기[2021.11.08 김민정]
		
		if(errors.hasErrors()) { // 아이디 유효성 실패
			
			//맵에 에러메세지 받아서 보여주기
			Map<String, String> validatorResult = loginUserService.validateHandling(errors);
			
			for(String key : validatorResult.keySet()) {
				model.addAttribute(key, validatorResult.get(key));
				System.out.println(key);
				
			}
			return "login";
		}
		
		else { //아이디 유효성 성공시 
				if(result == false) { //회원가입 실패 시
					return "errorPage"; 
				}
				else { //회원가입 성공시
					return "redirect:/mainPage";
				}
		
			}
	
	
	}
	
	
	@RequestMapping(value="/findid")
	public String findid(String findIdName, String findIdPhone){
		
		System.out.println(findIdName);
		System.out.println(findIdPhone);
		
		//boolean resultUserLoginInfo = loginService.userLoginInfo(findIdName, findIdEmail);
		//System.out.println("로그인 찾기를 위한 사용자 조회 :"+resultUserLoginInfo);
		
		return "findId"; // 원래는 loginPage.jsp로 해야되는데 viewResolver를 통해서 생략가능하다. => 생산성 향상 [2021.10.27 김민정]
	
	
	}
	@RequestMapping(value="/findpw")
	public String findpw(String findPwName, String findPwEmail){
		
		System.out.println(findPwName);
		System.out.println(findPwEmail);
		
		return "findPw"; // 원래는 loginPage.jsp로 해야되는데 viewResolver를 통해서 생략가능하다. => 생산성 향상 [2021.10.27 김민정]
	
	
	}
	
	@RequestMapping(value="/loginErrorPage")
	public String loginerrorpage() {
		
		
		return "errorPage";
	}
	
}

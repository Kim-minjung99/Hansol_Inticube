package com.example.StudyMoa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@SpringBootApplication
public class StudyMoaApplication implements WebMvcConfigurer {

	public static void main(String[] args) {
		SpringApplication.run(StudyMoaApplication.class, args);
	}
	
	@Bean
	public InternalResourceViewResolver setupViewResolver(){
			InternalResourceViewResolver resolver = new InternalResourceViewResolver();
			
			resolver.setPrefix("WEB-INF/views/");
			resolver.setSuffix(".jsp");
			return resolver;
	}
}

package com.example.StudyMoa.common.service;

import java.util.Map;

public interface StudyMemberService {

	boolean insertStudyMember(Map<String, Object> map);

	Map<String, Object> selectStudyMember(Map<String, Object> map);

}

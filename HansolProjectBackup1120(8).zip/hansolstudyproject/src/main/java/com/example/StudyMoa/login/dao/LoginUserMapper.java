package com.example.StudyMoa.login.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.data.repository.query.Param;

import com.example.StudyMoa.login.dto.User;

@Mapper
public interface LoginUserMapper {

	boolean insertUser(User user);
	
	String findUserId(String userPhone);
	
	String findUserPwd(User user);

	int userIdCheck(HashMap<String, Object> paramData);
	
	User LoginIdCheck(String userId, String userPwd);		//아이디 조회
//	
//	//유저 정보
//	ArrayList<User> findByUserId(@Param("userId") String userId);
//
//	//유저 저장
//	int userSave(User userVO);
//
//	//유저 권한 저장
//	int userRoleSave(@Param("userNo") String userNo, @Param("roleNo") int roleNo);
//
//	//유저 FK번호 알아내기
//	int findUserNo(@Param("id") String id);
//
//	//권한 FK번호 알아내기
//	int findRoleNo(@Param("roleName") String roleName);
}

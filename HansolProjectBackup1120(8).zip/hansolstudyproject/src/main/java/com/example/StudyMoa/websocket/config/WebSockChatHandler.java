package com.example.StudyMoa.websocket.config;

import java.io.IOException;

import org.springframework.stereotype.Component;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class WebSockChatHandler extends TextWebSocketHandler{	//서버와 클라이언트는 1:N 관계, 서버에는 여러 클라이언트가 발송한 메시지를 받아 처리해주는 Handler
	
	protected void handleTextMessage(WebSocketSession session, TextMessage message) throws IOException{
		String payload = message.getPayload();
		log.info("payload {}", payload);
		
		TextMessage textMessage = new TextMessage("Welcome chatting server~^^");
		session.sendMessage(textMessage);
	}
	
	
}

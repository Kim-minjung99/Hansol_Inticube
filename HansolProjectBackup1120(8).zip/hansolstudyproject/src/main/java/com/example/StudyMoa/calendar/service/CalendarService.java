package com.example.StudyMoa.calendar.service;

import java.util.Calendar;
import java.util.HashMap;

import java.util.List;
import java.util.Map;

import com.example.StudyMoa.common.dto.Study;

public interface CalendarService {


	List<Map<String, Object>> selectCalendarList(Map<String, Object> myschedule);
		
	boolean insertCalendar(Map<String, Object> schedule);

	
	List<Map<String, Object>> selectCalendarListTest();

	
	// 삭제
	
	boolean deleteCalendar(Map<String, Object> schedule);

	// 수정 
	boolean updateCalendar(Map<String, Object> schedule);
	 

	}



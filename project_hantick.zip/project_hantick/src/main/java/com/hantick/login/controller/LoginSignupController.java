package com.hantick.login.controller; 


import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.hantick.login.service.AccountService;


@Controller
@RequestMapping("/")
public class LoginSignupController { 
	
	 private final Logger logger = LoggerFactory.getLogger(LoginSignupController.class.getName());
	
	@GetMapping("/login") 
	public String login() { 
		return "login"; 
	} 
	
	@Autowired
	AccountService accountService;
	
	@GetMapping("/signup") 
	public String signup(Model model) { 
		
		List<HashMap<String, Object>> position = accountService.getPosList();
		List<HashMap<String, Object>> department = accountService.getDeptList();
		
		model.addAttribute("department",department);
		model.addAttribute("position",position);
		return "signup"; 
	} 

	
	@RequestMapping(value = "/signup", method = RequestMethod.POST) // 회원가입 기타 정보 저장
	public String signup(@RequestParam HashMap map, HttpServletRequest request, Model model) { 
		
		MultipartHttpServletRequest multi = (MultipartHttpServletRequest) request;
		MultipartFile file = multi.getFile("user_photo");
			
		String path = "C:\\Users\\Hansol\\hantickimages\\";
		UUID randomUUID = UUID.randomUUID();
		
		String OriginFileName = file.getOriginalFilename(); 
		long fileSize = file.getSize();
		
		String safeFile = path + randomUUID + OriginFileName;
		
		try {
            file.transferTo(new File(safeFile));
        } catch (IllegalStateException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
		map.put("user_photo", safeFile);
		accountService.subjoin(map);	// ID, 비밀번호, 사진을 제외한 나머지 데이터
		accountService.mainjoin(map);	// ID, 비밀번호 저장
		
		return "login"; 
	}


	@ResponseBody
	@RequestMapping(value = "/signup/idCheck", method = RequestMethod.GET)
	public int idCheck(@RequestParam("username") String username) {
		logger.info("전달받은 id"+ username);
		int cnt = accountService.userIdCheck(username);
		logger.info("확인결과 :"+ cnt);
		System.out.println(cnt);
		return cnt;
	}
	
	@RequestMapping("/accessDenied") 
	public String accessDenied() { 
		return "accessDenied"; 
	}
}

package com.hantick.login.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.hantick.common.dto.UserInfoDTO;
import com.hantick.login.dto.UserAuthenticationDTO;

@Service
public interface AccountService {
	
	void subjoin(HashMap a);
	void mainjoin(HashMap a);
	
	int userIdCheck(String username);
	List<HashMap<String, Object>> getPosList();
	List<HashMap<String, Object>> getDeptList();
	

}
package com.hantick.login.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.hantick.common.dto.UserInfoDTO;
import com.hantick.login.dto.UserAuthenticationDTO;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class CustomAuthenticationProvider implements AuthenticationProvider{

		@Autowired
	    private UserDetailsService userDeSer;
	 
	    @SuppressWarnings("unchecked")
	    @Override
	    public Authentication authenticate(Authentication authentication) throws AuthenticationException {
	        
	    	BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
	    	
	        String username = (String) authentication.getPrincipal();
	        String password = (String) authentication.getCredentials();
	        
	        System.out.print("Login ID : ");
	        System.out.println(username);
	        UserInfoDTO user = (UserInfoDTO) userDeSer.loadUserByUsername(username);
	        
	        if(!encoder.matches(password, user.getPassword())) {
		        System.out.print("Login Password : ");
		        System.out.println(password);
		        System.out.print("Login FAIL");
		        
	        	throw new BadCredentialsException(username);
	        }
	        // 여기서부터는 예외 처리부분임 활성화가 되었는지를 판단하는 부분인데 지금은 안쓸예정임 Enabled 변수를 사용하지 않기 때문임
	        if(!user.isEnabled()) {
	            throw new BadCredentialsException(username);
	        }
	        System.out.print("Login Password : ");
	        System.out.println(password);
	        System.out.print("Login SUCCESS");
	        UsernamePasswordAuthenticationToken result = new UsernamePasswordAuthenticationToken(user, null, user.getAuthorities());
	        return result;
	    }
	 
	    @Override
	    public boolean supports(Class<?> authentication) {
	        return true;
	    }

}

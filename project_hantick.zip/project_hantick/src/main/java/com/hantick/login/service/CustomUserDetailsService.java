package com.hantick.login.service;

import java.util.ArrayList;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.hantick.common.dto.UserInfoDTO;
import com.hantick.login.dao.UserAuthDAO;
import com.hantick.login.dto.UserAuthenticationDTO;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
// UserDetailsService는 유저의 정보는 DB에서 가져오는 역할을 합니다.
public class CustomUserDetailsService implements UserDetailsService{

	@Autowired
	private SqlSessionTemplate sqlSession;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
//		ArrayList<String> authList = new ArrayList<String>();
		UserAuthDAO dao = sqlSession.getMapper(UserAuthDAO.class);
		
		UserInfoDTO userDetailsDto = dao.selectUserInfo(username);
//		authList = dao.getAuthList(username);

		if (userDetailsDto == null) { //User을 찾지 못했을 경우
			System.out.println(username);
			System.out.println("해당 유저는 아이디가 등록되어있지 않습니다.");
			throw new UsernameNotFoundException(username);
		}

		return userDetailsDto; //완전한 UserDetails 객체
	}
}
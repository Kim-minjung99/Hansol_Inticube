package com.hantick.login.dao;

import java.util.HashMap;
import java.util.List;

import org.springframework.ui.Model;

import com.hantick.common.dto.UserInfoDTO;
import com.hantick.login.dto.UserAuthenticationDTO;

public interface UserAuthDAO {
	UserInfoDTO getAccountById(String id);
	// 유저 아이디와 비밀번호 가져오기 위한 부분
	public UserAuthenticationDTO selectUser(String username);
	public UserInfoDTO selectUserInfo(String username);
	
	// 회원가입시 정보 저장에 사용되는 부분
	void subAccount(HashMap account);
	void mainAccount(HashMap account);
	
	// 회원가입시 중복체크에 사용되는 부분
	int checkOverId(String username);
	List<HashMap<String, Object>> getPosList();
	List<HashMap<String, Object>> getDeptList();
	

}
package com.hantick.login.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import com.hantick.login.dao.UserAuthDAO;
import com.hantick.login.service.AccountService;
import java.util.HashMap;
import java.util.List;
import org.mybatis.spring.SqlSessionTemplate;


@Service
public class AccountServiceImpl implements AccountService{
	
	@Autowired
	UserAuthDAO accountMapper;
	
	@Autowired
	private SqlSessionTemplate sqlSession;

	@Override
	public void subjoin(HashMap a) {
		accountMapper.subAccount(a);	
	}

	@Override
	public void mainjoin(HashMap a) {
		
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		String securePw = encoder.encode((CharSequence) a.get("password"));
		a.put("password", securePw);
		accountMapper.mainAccount(a);		
	}
	
	@Override
	public int userIdCheck(String username) {

		UserAuthDAO dao = sqlSession.getMapper(UserAuthDAO.class);

		return dao.checkOverId(username);
	}

	@Override
	public List<HashMap<String, Object>> getPosList() {
		
		return accountMapper.getPosList();
	}

	@Override
	public List<HashMap<String, Object>> getDeptList() {
		
		return accountMapper.getDeptList();
	}

}
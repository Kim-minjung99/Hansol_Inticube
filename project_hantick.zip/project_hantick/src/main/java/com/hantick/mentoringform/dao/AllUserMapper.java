package com.hantick.mentoringform.dao;

import java.util.HashMap;
import java.util.List;

public interface AllUserMapper {
	
//	public List<AllUserDTO> selectAll(AllUserDTO dto);
//	
//	public AllUserDTO selectOne(AllUserDTO dto);
	
	/* 멘토링 신청하기 */
	void insertForm(HashMap form);
	
	/* 멘토의 이름, 팀, 직책, 이메일 불러오기 */
	public HashMap<String, Object> selectMentor(int mentor_seq);

}

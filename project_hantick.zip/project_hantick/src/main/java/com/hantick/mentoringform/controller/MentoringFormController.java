package com.hantick.mentoringform.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.hantick.mentoringform.service.AllUserService;
import com.hantick.mentoringlist.service.UserService;


@Controller
public class MentoringFormController {
	
	@Autowired
	AllUserService allUserService;
	
	@Autowired
	UserService userService;	// MentoringList에서 받아오는 userService
	
	@Autowired
	JavaMailSender javaMailSender;
	
	@GetMapping("insertBoard")
	public String insertBoard(Model model) {
		
		HashMap<String, Object> randommentor = userService.getRandomMentor();
		
		model.addAttribute("randomMentor", randommentor);
		return "mentoringForm/insertBoard";
	}
	
	@PostMapping("insertBoard")
	public String insertBoard(@RequestParam HashMap map, @RequestParam("mentor_seq") int mentor_seq) {
		
		SimpleMailMessage message = new SimpleMailMessage();
		
		// 신청한 멘토의 정보를 가져오는 부분(멘토의 이메일을 가져오기 위함) 
		// 즉, 아래 부분은 Select 구분이 되어야 됨 
		// 하지만, View 단 까지 정보를 넘기지는 않고 Controller 상에서 Email을 전송하기 위한 데이터
		HashMap<String, Object> mentor = allUserService.selectMentor(mentor_seq); 
		message.setFrom("dooly6618@naver.com");
		message.setTo((String) mentor.get("user_email"));
		message.setSubject("멘토링 신청이 왔습니다. - 한틱");
		message.setText((String)mentor.get("user_name")+"님, 멘토링 신청이 왔습니다. 자세한 내용은 한틱을 이용해주시기 바랍니다.");
		javaMailSender.send(message);
		System.out.println("멘토에게 이메일을 보냈습니다.");

		

		allUserService.insertForm(map);

		
		return "mentoringForm/mentorInfo";
	}
	
}

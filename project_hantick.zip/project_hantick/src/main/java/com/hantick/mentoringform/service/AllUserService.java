package com.hantick.mentoringform.service;

import java.util.HashMap;



public interface AllUserService {

	/* 멘토링 신청하기 */
	void insertForm(HashMap form);
	
	public HashMap<String, Object> selectMentor(int mentor_seq);

}

package com.hantick.mentoringform.service.impl;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hantick.mentoringform.dao.AllUserMapper;
import com.hantick.mentoringform.service.AllUserService;

@Service
public class AllUserServiceImpl implements AllUserService {
	
	@Autowired
	AllUserMapper allUserMapper;

	/* 멘토링 신청하기 */
	@Override
	public void insertForm(HashMap form) {
		allUserMapper.insertForm(form);		
	}

	@Override
	public HashMap<String, Object> selectMentor(int mentor_seq) {

		return allUserMapper.selectMentor(mentor_seq);
	}

}

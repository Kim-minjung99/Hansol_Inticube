package com.hantick.mypage.controller;

import java.util.HashMap;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hantick.common.dto.UserInfoDTO;
import com.hantick.mentoringlist.service.UserService;
import com.hantick.mypage.service.GetListService;
import com.hantick.mypage.service.InsertReviewSerivce;
import com.hantick.mypage.service.MyPageButtonService;

@Controller
public class MyPageController {

	@Autowired
	GetListService getlistservice;
	
	@Autowired
	MyPageButtonService btnservice;
	
	@Autowired
	InsertReviewSerivce insertreviewservice;
	
	@GetMapping("/mypage")
	public String mypage(@AuthenticationPrincipal UserInfoDTO userDetailsDto, Model model) throws Exception{	
		
		int user_seq = userDetailsDto.getUser_seq();
		List<HashMap<String, Object>> allList = getlistservice.getallList(user_seq);
		List<HashMap<String, Object>> receiveList = getlistservice.getreceiveList(user_seq);
		List<HashMap<String, Object>> sendList = getlistservice.getsendList(user_seq);
		
		model.addAttribute("user_info", userDetailsDto);
		model.addAttribute("allList", allList);
		model.addAttribute("receiveList", receiveList);
		model.addAttribute("sendList", sendList);

		return "mypage"; 
	}

	@ResponseBody
	@RequestMapping(value = "/mypage/changestatus", method = RequestMethod.POST)
	public int changestatus(@RequestBody HashMap<String, Object> map) {

		btnservice.updateState((String)map.get("status"), (String)map.get("mentoring_seq"));
		String state = btnservice.resultState((String)map.get("mentoring_seq"));
		
		if(state == "refuse") {	// 상태가 refuse일 경우 0, accept일 경우 1을 반환
			return 0;
		} else {
			return 1;
		}
	}	
	
	@ResponseBody
	@RequestMapping(value = "/mypage", method = RequestMethod.POST)
	public String mypage(@RequestParam HashMap map) {
			
		System.out.println(map);
		
		// Review를 Insert 하는 부분
		insertreviewservice.insertReview(map);
		
		// 이후 해당 Mentoring List의 Flag를 변경하는 부분
		int mentoring_seq =  Integer.parseInt(String.valueOf(map.get("inputmentoringseq")));
		insertreviewservice.updateReview(mentoring_seq);
			
		return "redirect:/mypage";
		
	}
	
}

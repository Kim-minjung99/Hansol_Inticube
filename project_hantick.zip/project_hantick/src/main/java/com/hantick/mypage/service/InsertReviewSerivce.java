package com.hantick.mypage.service;

import java.util.HashMap;

public interface InsertReviewSerivce {

	void insertReview(HashMap map);

	void updateReview(int mentoring_seq);

}

package com.hantick.mypage.service;

import java.util.HashMap;
import java.util.List;

public interface GetListService {

	public List<HashMap<String, Object>> getallList(int user_seq);

	public List<HashMap<String, Object>> getreceiveList(int user_seq);

	public List<HashMap<String, Object>> getsendList(int user_seq);

}

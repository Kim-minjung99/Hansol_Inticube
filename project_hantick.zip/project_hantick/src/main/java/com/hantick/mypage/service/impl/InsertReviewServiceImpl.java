package com.hantick.mypage.service.impl;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hantick.mypage.dao.MyPageMapper;
import com.hantick.mypage.service.InsertReviewSerivce;

@Service
public class InsertReviewServiceImpl implements InsertReviewSerivce{

	@Autowired
	MyPageMapper mypagemapper;
	
	@Override
	public void insertReview(HashMap map) {
		mypagemapper.insertReview(map);
		
	}

	@Override
	public void updateReview(int mentoring_seq) {
		mypagemapper.updateReview(mentoring_seq);
		
	}
	
}

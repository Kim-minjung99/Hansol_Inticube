package com.hantick.mypage.service.impl;

import java.util.HashMap;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hantick.mypage.dao.MyPageMapper;
import com.hantick.mypage.service.MyPageButtonService;

@Service
public class MyPageButtonServiceImpl implements MyPageButtonService{

	@Autowired
	MyPageMapper mypagemapper;
	
	@Override
	public void updateState(String status, String mentoring_seq) {
		mypagemapper.updatestate(status, mentoring_seq);
	}

	@Override
	public String resultState(String mentoring_seq) {
		return mypagemapper.resultstate(mentoring_seq);	
	}
}

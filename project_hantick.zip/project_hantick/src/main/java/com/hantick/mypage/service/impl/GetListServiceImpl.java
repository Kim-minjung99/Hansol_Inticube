package com.hantick.mypage.service.impl;

import java.util.HashMap;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hantick.mypage.dao.MyPageMapper;
import com.hantick.mypage.service.GetListService;

@Service
public class GetListServiceImpl implements GetListService{

	@Autowired
	MyPageMapper mypagemapper;
	
	@Override
	public List<HashMap<String, Object>> getallList(int user_seq){
		return mypagemapper.selectAll(user_seq);
	}

	@Override
	public List<HashMap<String, Object>> getreceiveList(int user_seq) {
		return mypagemapper.selectreceive(user_seq);
	}
	
	@Override
	public List<HashMap<String, Object>> getsendList(int user_seq) {
		return mypagemapper.selectsend(user_seq);
	}
}

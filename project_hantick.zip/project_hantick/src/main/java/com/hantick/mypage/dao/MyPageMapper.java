package com.hantick.mypage.dao;

import java.util.HashMap;
import java.util.List;

public interface MyPageMapper {

	public List<HashMap<String, Object>> selectAll(int user_seq);

	public List<HashMap<String, Object>> selectreceive(int user_seq);

	public List<HashMap<String, Object>> selectsend(int user_seq);
	
	public void updatestate(String status, String mentoring_seq);
	
	public String resultstate(String mentoring_seq);

	public void insertReview(HashMap map);

	public void updateReview(int mentoring_seq);
}

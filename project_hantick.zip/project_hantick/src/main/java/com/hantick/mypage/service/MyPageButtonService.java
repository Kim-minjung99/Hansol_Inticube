package com.hantick.mypage.service;

import java.util.HashMap;
import java.util.List;


public interface MyPageButtonService {
	
	public void updateState(String status, String mentoring_seq);

	public String resultState(String mentoring_seq);

}
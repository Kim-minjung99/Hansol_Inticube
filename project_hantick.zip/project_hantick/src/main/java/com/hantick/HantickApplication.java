package com.hantick;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HantickApplication {

	public static void main(String[] args) {
		SpringApplication.run(HantickApplication.class, args);
	}

}

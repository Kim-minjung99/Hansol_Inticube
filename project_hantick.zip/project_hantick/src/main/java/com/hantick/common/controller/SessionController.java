package com.hantick.common.controller;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.text.html.HTMLDocument.Iterator;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.hantick.common.dto.UserInfoDTO;

public class SessionController{
	
	public UserInfoDTO userinfo(@AuthenticationPrincipal UserInfoDTO userDetailsDto) {
		int user_seq = userDetailsDto.getUser_seq();
		String user_name = userDetailsDto.getUser_name();
		String username = userDetailsDto.getUsername();
		String user_email = userDetailsDto.getUser_email();
		String user_department = userDetailsDto.getUser_department();
		return userDetailsDto;
	}
	
}


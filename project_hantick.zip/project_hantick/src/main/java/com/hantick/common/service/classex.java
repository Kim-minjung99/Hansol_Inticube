package com.hantick.common.service;

public class classex {

}

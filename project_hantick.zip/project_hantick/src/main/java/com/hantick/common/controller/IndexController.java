package com.hantick.common.controller;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hantick.common.dto.UserInfoDTO;

@Controller
@RequestMapping("/")
public class IndexController{
	
	
	@GetMapping("/index")
	public String index(@AuthenticationPrincipal UserInfoDTO userDetailsDto, Model model) throws Exception {

		model.addAttribute("user_info",userDetailsDto);
		
		return "index";
    }
}

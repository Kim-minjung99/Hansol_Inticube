package com.hantick.common.config;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.zaxxer.hikari.HikariConfig;

@Configuration
@MapperScan(basePackages = "com.hantick.*.dao")
@EnableTransactionManagement
public class MyBatisConfig {
	
//	HikariConfig hikariDSObject = new HikariConfig();
	
	@Bean
    public JdbcTemplate jdbcTemplate(DataSource dataSource)
    {
     return new JdbcTemplate(dataSource, false);
    }
	
	@Bean
    public SqlSessionFactory sqlSessionFactory (DataSource dataSource) throws Exception {
		 SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
		 PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
		 bean.setDataSource(dataSource);
		 bean.setMapperLocations(resolver.getResources("classpath:mapper/*.xml"));
		 return bean.getObject();
    }
    
    @Bean
    public SqlSessionTemplate sqlSession (SqlSessionFactory sqlSessionFactory) {
        
        return new SqlSessionTemplate(sqlSessionFactory);
    }
	
}

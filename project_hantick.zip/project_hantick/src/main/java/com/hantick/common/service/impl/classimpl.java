package com.hantick.common.service.impl;

public class classimpl {

}

package com.hantick.common.dto;


import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class UserInfoDTO implements UserDetails{
	
	private int user_seq;
	private String username;	// 이게 아이디임
	private String password;
	private String user_name;	// 이건 실명
	private String user_email;
	private String user_department;
	private String user_position;
	private String user_photo;
	private String user_point;
	private String department_name;
	private String position_name;

    @Override
    public String getUsername() {
         return username;
    }

    @Override
    public String getPassword() {
         return password;
    }

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}
	
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		return null;
	}
}
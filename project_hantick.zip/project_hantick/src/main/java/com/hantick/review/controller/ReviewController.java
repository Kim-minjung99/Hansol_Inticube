package com.hantick.review.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.hantick.review.service.ReviewService;


@Controller
@RequestMapping("/")
public class ReviewController {

	@Autowired
	ReviewService reviewService;
	
	@ResponseBody
	@RequestMapping(value = "/mentorlist/list", method = RequestMethod.GET)
	public Object getReviewList(Model model,@RequestParam("mentor_seq") int mentor_seq){

		System.out.println(mentor_seq);

		List<HashMap<String, Object>> reveiwList = reviewService.getReview(mentor_seq);
		System.out.println(reveiwList);
		model.addAttribute("reveiwList", reveiwList);
		return reveiwList;
	}
}


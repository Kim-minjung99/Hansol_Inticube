package com.hantick.review.service.impl;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hantick.review.dao.ReviewMapper;
import com.hantick.review.service.ReviewService;

@Service
public class ReviewServiceImpl implements ReviewService {
	
	@Autowired
	ReviewMapper mypageMapper;
	 
	@Override
	public List<HashMap<String, Object>> getReviewList() {
		return mypageMapper.getReviewList();
	}

	@Override
	public List<HashMap<String, Object>> getReview(int mentor_seq) {
		return mypageMapper.getReview(mentor_seq);
	}

}

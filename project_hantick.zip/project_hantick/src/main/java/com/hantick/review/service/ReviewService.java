package com.hantick.review.service;

import java.util.HashMap;
import java.util.List;

public interface ReviewService {
	
	public List<HashMap<String, Object>> getReviewList();
	
	public List<HashMap<String, Object>> getReview(int mentor_seq);

}

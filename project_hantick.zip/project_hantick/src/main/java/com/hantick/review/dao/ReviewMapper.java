package com.hantick.review.dao;

import java.util.HashMap;
import java.util.List;

public interface ReviewMapper {

	public List<HashMap<String, Object>> getReviewList();
	
	public List<HashMap<String, Object>> getReview(int mentor_seq);
}

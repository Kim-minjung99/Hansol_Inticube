package com.hantick.mentoringlist.service.impl;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hantick.mentoringlist.dao.UserMapper;
import com.hantick.mentoringlist.service.UserService;


@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	UserMapper uMapper;
	
	@Override
	public List<HashMap<String, Object>> getMentorList() {
		return uMapper.selectAllMentor();
	}
	
	@Override
	public HashMap<String, Object> getRandomMentor() {
		return uMapper.selectRandomMentor();
	}
	 
}

package com.hantick.mentoringlist.service;

import java.util.HashMap;
import java.util.List;



public interface UserService {
	
	/* 전체 멘토리스트 조회 */
	public List<HashMap<String, Object>> getMentorList();
	
	/* 랜덤한 사원데이터 조회 */
	public HashMap<String, Object> getRandomMentor();
}

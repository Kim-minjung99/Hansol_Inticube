package com.hantick.mentoringlist.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hantick.common.dto.UserInfoDTO;
import com.hantick.mentoringlist.service.UserService;

@Controller
@RequestMapping("/")
public class MentorlistController{

	
	// DB에서 user정보 불러오기 
	@Autowired
	UserService userService;
	
	@GetMapping("/mentorlist")
	public String mentorlist(@AuthenticationPrincipal UserInfoDTO userDetailsDto, Model model) {	

		List<HashMap<String, Object>> mentorList = userService.getMentorList();  // 전체 멘토리스트 조회
		model.addAttribute("mentorList",mentorList);
		
		HashMap<String, Object> randomMentor = userService.getRandomMentor();  // 랜덤한 멘토조회
		model.addAttribute("data",randomMentor);
		
		// 사용자 seq 받아오는 부분
		int user_seq = userDetailsDto.getUser_seq();
		model.addAttribute("user_info",userDetailsDto);
		model.addAttribute("user_seq",user_seq);
		
		// Gson 라이브러리 (java -> json) 
		Map<String, List> jsonMap = new HashMap<String, List>();
		jsonMap.put("mentorList",mentorList);

		Gson gson = new GsonBuilder().create();
		String json = gson.toJson(jsonMap);
		
		System.out.println(json);
		
		model.addAttribute("result", json );

		return "mentorlist"; 
	}
}

package com.hantick.mentoringlist.dao;

import java.util.HashMap;
import java.util.List;


public interface UserMapper {

	public List<HashMap<String, Object>> selectAllMentor();
	public HashMap<String, Object> selectRandomMentor();
}

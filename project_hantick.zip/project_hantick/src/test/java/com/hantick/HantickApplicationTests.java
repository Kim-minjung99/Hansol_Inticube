package com.hantick;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HantickApplicationTests {

	@Test
	void contextLoads() {
	}

}

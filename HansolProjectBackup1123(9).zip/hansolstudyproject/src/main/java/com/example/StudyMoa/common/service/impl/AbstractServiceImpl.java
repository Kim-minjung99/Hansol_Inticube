package com.example.StudyMoa.common.service.impl;

import java.util.List;

import com.example.StudyMoa.common.service.AbstractService;

public class AbstractServiceImpl implements AbstractService{

	@Override
	public void printQueryId(String queryId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Object insert(String queryId, Object params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object update(String queryId, Object params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object delete(String queryId, Object params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object selectOne(String queryId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Object selectOne(String queryId, Object params) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List selectList(String queryId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List selectList(String queryId, Object params) {
		// TODO Auto-generated method stub
		return null;
	}

}

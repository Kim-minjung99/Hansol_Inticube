package com.example.StudyMoa.websocket.service;

import java.util.HashMap;

public interface AlarmService {

	boolean insertAlarm(HashMap<String, Object> paramData);

}

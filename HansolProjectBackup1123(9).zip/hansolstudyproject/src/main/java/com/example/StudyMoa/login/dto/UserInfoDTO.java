package com.example.StudyMoa.login.dto;

public class UserInfoDTO {

}

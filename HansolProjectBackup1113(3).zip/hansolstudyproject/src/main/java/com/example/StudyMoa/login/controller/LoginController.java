package com.example.StudyMoa.login.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.annotation.AuthenticationPrincipal;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.StudyMoa.common.dto.Category;
import com.example.StudyMoa.common.service.CategoryService;
import com.example.StudyMoa.common.service.StudyService;
import com.example.StudyMoa.login.dto.User;
import com.example.StudyMoa.login.service.LoginUserService;
//import com.example.StudyMoa.login.service.impl.SecurityServiceImpl;
import com.example.StudyMoa.login.service.impl.SecurityAuth.UserPrincipal;

import ch.qos.logback.core.recovery.ResilientSyslogOutputStream;


//LoginController : 로그인하여 이동하는 페이지 매핑(2021.10.27 김민정)

@Controller
public class LoginController {
	

	
	@Autowired //LoginService대신 insertUserSerivce정의
	LoginUserService loginUserService;
	
	@Autowired
	CategoryService categoryService;
	
	@RequestMapping(value="/login")
	public String LoginPage(HttpServletRequest request, @RequestParam("userId") String userId, @RequestParam("userPwd") String userPwd, @AuthenticationPrincipal UserPrincipal userPrincipal){

		//사용자가 입력한 user 정보 확인
		System.out.println(userId);
		System.out.println(userPwd);
		

		//빈 등록 확인
//		System.out.println("insertUserLogin 빈확인 :"+loginUserService);
//		System.out.println("시큐리티서비스임플 빈확인:"+securityServiceImpl);
//		
//		UserDetails resultUserLoginInfo = securityServiceImpl.loadUserByUsername(userId);
//		System.out.println("사용자 입력 id,pw 조회 여부 : "+resultUserLoginInfo);
//
//		if(resultUserLoginInfo==null) { //로그인 실패시 다시 로그인 창으로 돌아간다.
//			
//			
//			
//			return "errorPage";
//		}
//		
//		else { //로그인 성공시 메인 페이지로 들어갈 수 있다.
//			
//			HttpSession session=request.getSession();
//			
//			if (session==null) {
//				System.out.println("session is false");
//				return "errorPage";
//			}
//			else {
//				System.out.println("session is true");
////				Iterator<? extends GrantedAuthority> iter = userPrincipal.getAuthorities().iterator();
////				while(iter.hasNext()) {
////					GrantedAuthority auth = iter.next();
////					System.out.println(auth.getAuthority());
////				}
////				
		//return "redirect:/mainPage"; //다른사람의 컨트롤러 단으로 들어가게 될때는 redirect:/도메인 주소 로 들어가야 한다.[2021.11.03 김민정]

			//}
			
			
			
		//}
		
		
		
		//loginService.userLoginInfo(userId,userPwd);
		return "loginPage"; // 원래는 loginPage.jsp로 해야되는데 viewResolver를 통해서 생략가능하다. => 생산성 향상 [2021.10.27 김민정]
	}
	

	
	
//	@RequestMapping(value="/joinForm")
//	public String JoinPage(@Valid User user, Errors errors, Model model){ //joinPage() 파라미터 안의 정의된 객체정보가 담겨져있는 User클래스 객체 user에 대해 입력할 수 있는 정보를 찾고
//		
//		System.out.println("유저정보"+ user);
//		
//		if(errors.hasErrors()) { // 아이디 유효성 실패
//			
//			//  회원가입 실패시, 입력 데이터를 유지 주석처리하고 다시 확인하기
//	        //model.addAttribute("user", user);
//	        
//	        
//
//			//맵에 에러메세지 받아서 보여주기
//			Map<String, String> validatorResult = loginUserService.validateHandling(errors);
//			
//			for(String key : validatorResult.keySet()) {
//				
//				model.addAttribute(key, validatorResult.get(key));
//				System.out.println(model.addAttribute(key, validatorResult.get(key)));
//	
//			}
//			return "joinPage";
//			
//		}
//		
//		else { //유효성 에러메세지가 없을때
//			
//			//해쉬맵 사용시 value값 넣을때 형태를 정할땐 상위버전으로 object로 선언해줘야 편하다
//			//Map<String,Object> userConfirmPasswd = new HashMap<>();
//			
//			//해쉬맵에 값넣기
//			//userConfirmPasswd.put("user", user);
//			
//			//System.out.println(userConfirmPasswd.put("user", user).getClass().getName());		//user클래스 해쉬맵에 담아서 형태 확인 com.example.StudyMoa.login.dto.User
//			
//			
//			boolean result = loginUserService.insertUser(user);			//https://www.youtube.com/watch?v=0JHIME7uGOk
//			System.out.println(user);
//			
//			if(result == false) { //회원가입 실패 시
//					return "errorPage"; 
//				}
//				
//				else { //회원가입 성공시
//					return "redirect:/mainPage";
//				}
//			
//		
//			}
//	//return "redirect:/mainPage";
//	
//	}
	@RequestMapping(value="/join")
	public String JoinPage(Model model) throws Exception{
		
		List<Category> categoryList = categoryService.selectCategoryList();			//카테고리 리스트 조회
		model.addAttribute("categoryList", categoryList);							//카테고리 리스트 모델 객체 add
		
		return "joinPage";
	}
	
	@RequestMapping(value="/joinForm", method = {RequestMethod.GET})
	public String JoinPage(@Valid User user,Errors errors, Model model) throws Exception{ //joinPage() 파라미터 안의 정의된 객체정보가 담겨져있는 User클래스 객체 user에 대해 입력할 수 있는 정보를 찾고
		
		List<Category> categoryList = categoryService.selectCategoryList();			//카테고리 리스트 조회
		model.addAttribute("categoryList", categoryList);							//카테고리 리스트 모델 객체 add
		
		
		//사용자 UI에서 입력한 데이터를 해당 모델(model)에 담아서 정보를 찍어준다. [2021.10.29 김민정]
		if(errors.hasErrors()) { // 아이디 유효성 실패 (에러가 있다면)
			
			//맵에 에러메세지 받아서 보여주기
			Map<String, String> validatorResult = loginUserService.validateHandling(errors);
			
			
			//히든처리 필요 만약에 에러가 있다면?(NOT NULL) .HIDE(),, JSP단에서도 SPAN태그에 값이 들어가게 될 것이고, 에러가 없을때 NULL값이 들어오면 .SHOW()
			for(String key : validatorResult.keySet()) {
				
				model.addAttribute(key, validatorResult.get(key));
				//System.out.println(model.addAttribute(key, validatorResult.get(key)));
				System.out.println("모델은 :"+model);
	
			}
			return "joinPage";
			
		}
		
		else { //유효성 성공 (에러메세지가 없을때)
			
			//해쉬맵 사용시 value값 넣을때 형태를 정할땐 상위버전으로 object로 선언해줘야 편하다
			//Map<String,Object> userConfirmPasswd = new HashMap<>();
			
			//해쉬맵에 값넣기
			//userConfirmPasswd.put("user", user);
			
			//System.out.println(userConfirmPasswd.put("user", user).getClass().getName());		//user클래스 해쉬맵에 담아서 형태 확인 com.example.StudyMoa.login.dto.User
			
			
			boolean result = loginUserService.insertUser(user);			//https://www.youtube.com/watch?v=0JHIME7uGOk
			System.out.println(user);
			
			if(result == false) { //회원가입 실패 시
					return "errorPage"; 
				}
				
				else { //회원가입 성공시
					return "redirect:/mainPage";
				}
			
		
			}
	}
	
//	@RequestMapping(value="/userConfirmPwd")
//	@ResponseBody
//	public boolean userConfirmPwd (@RequestBody HashMap <String,Object> Passwd) {
//		
//		String userPwd = (String) Passwd.get(userPwd);
//		String userConfirmPwd = Passwd.get(userConfirmPwd);
////		String userConfirmPwd = Passwd.get(userPwd)
////		
////		if(userConfirmPwd.equals(userPwd)) 
////		
//		return true;
//		
//		
//		
//	}
	
	
	@RequestMapping(value="/findid")
	public String findid(String findIdName, String findIdPhone){
		
		System.out.println(findIdName);
		System.out.println(findIdPhone);
		
		//boolean resultUserLoginInfo = loginService.userLoginInfo(findIdName, findIdEmail);
		//System.out.println("로그인 찾기를 위한 사용자 조회 :"+resultUserLoginInfo);
		
		return "findId"; // 원래는 loginPage.jsp로 해야되는데 viewResolver를 통해서 생략가능하다. => 생산성 향상 [2021.10.27 김민정]
	
	
	}
	@RequestMapping(value="/findpw")
	public String findpw(String findPwName, String findPwEmail){
		
		System.out.println(findPwName);
		System.out.println(findPwEmail);
		
		return "findPw"; // 원래는 loginPage.jsp로 해야되는데 viewResolver를 통해서 생략가능하다. => 생산성 향상 [2021.10.27 김민정]
	
	
	}
	
	@RequestMapping(value="/loginErrorPage")
	public String loginerrorpage() {
		
		
		return "errorPage";
	}
	
	@RequestMapping(value="/userIdCheck")
	@ResponseBody
	public int userIdCheck(@RequestBody HashMap<String,Object> paramData){
		
		System.out.println("userIdCheck 실행 : "+paramData);
		
		int result = loginUserService.userIdCheck(paramData);
		
		return result;
	}
	
	
	
	
	
}

package com.example.StudyMoa.common.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.StudyMoa.common.dao.AdminMapper;
import com.example.StudyMoa.common.dto.Category;
import com.example.StudyMoa.common.service.AdminService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class AdminServiceImpl implements AdminService{
	
	
	@Autowired
	AdminMapper adminMapper;

	@Override
	public boolean insertCategory(Category category) {
		// TODO Auto-generated method stub
		return adminMapper.insertCategory(category);
	}
	
	
	
}

package com.example.StudyMoa.login.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;

import com.example.StudyMoa.login.dao.LoginUserMapper;
import com.example.StudyMoa.login.dto.User;
import com.example.StudyMoa.login.service.LoginUserService;


@Service
public class LoginUserServiceImpl implements LoginUserService{

	
	@Autowired PasswordEncoder passwordEncoder;
	 
	@Autowired
	LoginUserMapper loginUserMapper;
	
	@Override
	public boolean insertUser(User user) {				//비밀번호와 서브비밀번호 비교, 인서트 유저
		
			
		/*
		 * String encodedPassword = passwordEncoder.encode(user.getUserPwd());
		 * user.setUserPwd(encodedPassword);
		 */
		return loginUserMapper.insertUser(user);

	}

	@Override
	public String findUserId(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String findUserPwd(User user) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override //해쉬맵에 키와 에러메세지를 담아주기
	public Map<String, String> validateHandling(Errors errors) {
		Map<String,String> validatorResult = new HashMap<>();
		
		for(FieldError error : errors.getFieldErrors()) {
			String validKeyName = String.format("valid_%s", error.getField());
			validatorResult.put(validKeyName, error.getDefaultMessage());
		}
		
		return validatorResult;
		
	}

	@Override
	public int userIdCheck(HashMap<String, Object> paramData) {
		
		System.out.println("서비스임플 확인");
		return loginUserMapper.userIdCheck(paramData);
	}

}

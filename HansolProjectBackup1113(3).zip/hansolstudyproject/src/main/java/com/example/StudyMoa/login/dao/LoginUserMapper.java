package com.example.StudyMoa.login.dao;

import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;

import com.example.StudyMoa.login.dto.User;

@Mapper
public interface LoginUserMapper {

	boolean insertUser(User user);
	
	String findUserId(User user);
	
	String findUserPwd(User user);

	int userIdCheck(HashMap<String, Object> paramData);

}

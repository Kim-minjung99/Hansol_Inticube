//package com.example.StudyMoa.login.service.impl;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.userdetails.UserDetails;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//import org.springframework.stereotype.Service;
//import com.example.StudyMoa.login.dto.User;
//import com.example.StudyMoa.login.service.impl.SecurityAuth.UserPrincipal;
//
//@Service
//public class SecurityServiceImpl implements UserDetailsService{ //기존의 로그인 서비스impl단으로부터 독립해서 나와서 userDetailsService를 상속받아쓴다  
//
////	@Autowired
////	private LoginMapper loginMapper;
//	
//	
//	public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException { 
//		
//		User user = loginMapper.selectByUserId(userId);
//		System.out.println("loginMapper.selectByUserId(userId) : "+user);
//		
//		if(user == null) {
//			throw new UsernameNotFoundException(userId+"is not found");
//		}
//		
//		return new UserPrincipal(user); 
//		//user형태로 돌려받은 resultUserLoginInfo는 이후 userDetailsService로부터 메소드가 호출되어 리턴값으로 돌려받은 userDetails값을
//		//user class와 userDetails 인터페이스를 상속받은 userPrincipal class에 저장시켜서 사용한다.
//	}
//	
//
//	
//	
//
//}

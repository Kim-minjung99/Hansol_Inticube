package com.example.StudyMoa.common.service;

import com.example.StudyMoa.common.dto.Category;

public interface AdminService {

	boolean insertCategory(Category category);

}

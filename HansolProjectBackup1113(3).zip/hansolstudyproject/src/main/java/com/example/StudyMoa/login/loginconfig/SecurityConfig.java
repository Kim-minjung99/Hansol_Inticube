package com.example.StudyMoa.login.loginconfig;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
//
//import com.example.StudyMoa.login.service.impl.SecurityServiceImpl;

@Configuration
@EnableWebSecurity //스프링 시큐리티 필터가 필터체인 안에 등록되어 사용될 수 있게 하는 어노테이션이다. [2021.11.04 김민정]
public class SecurityConfig extends WebSecurityConfigurerAdapter{
	

	
	 	@Bean
	    public PasswordEncoder passwordEncoder() {
	        return new BCryptPasswordEncoder();
	    }
		
	
	
//	 @Bean public DaoAuthenticationProvider
//	 daoAuthenticationProvider(SecurityServiceImpl securityServiceImpl) {
//	 DaoAuthenticationProvider daoAuthenticationProvider = new
//	 DaoAuthenticationProvider();
//	 daoAuthenticationProvider.setUserDetailsService(securityServiceImpl);
//	 daoAuthenticationProvider.setPasswordEncoder(passwordEncoder); return
//	 daoAuthenticationProvider; }
//	 
//	
	 @Override protected void configure(AuthenticationManagerBuilder auth) {
	 //AuthenticationManagerBuilder이 실제 인증을 할 provider를 생성해주는 단계이다. //DB로부터 아이디,
	 //비번이 맞는지, 해당 유저가 어떤 권한을 가지고 있는지 체크
	 //auth.authenticationProvider(daoAuthenticationProvider(securityServiceImpl));
	 }
	 
	
	
	@Override
	public void configure(WebSecurity web) {
		//이미지, 자바 스크립트, css디렉토리 보안 설정
		//web.ignoring().antMatchers("/css/**","/js/**","/img/**");
	}
	

	@Override
	protected void configure(HttpSecurity httpsecurity) throws Exception { 
		//HTTP 관련 보안 설정 ** 가장 중요하다.
		 
		//csrf(Cross Site Request Forgery 사이트간 요청위조)
		//httpsecurity.csrf().disable();
		
		httpsecurity.authorizeRequests() // 인증된 사용자만 접근할 수 있게 한다.
		//.antMatchers("/mainPage").authenticated()
		//.antMatchers("/login/**", "/join/**", "/joinForm/**","/findid/**","/findpw/**").permitAll()
		.antMatchers("/join","/joinForm").permitAll()
		.anyRequest().permitAll() //위에 명시한 페이지 접근과 무관한 페이지는 모두 허용[2021.11.04 김민정]
		.and()
			.formLogin() // 로그인 페이지와 기타 로그인 처리, 성공 실패처리를 사용하겠다.
			.loginPage("/login") //사용자가 따로 만든 로그인 페이지를 사용하고자 할때 사용한다. (커스터마이징)
			//.loginProcessingUrl("/login-process") 
			//.defaultSuccessUrl("/login") // 로그인 성공하면 이동하는 URL
			.successForwardUrl("/mainPage")
			.failureUrl("/errorPage") //로그인 실패하면 이동하는 URL
			.usernameParameter("userId")
			.passwordParameter("userPwd")
			.permitAll();
//		
//		httpsecurity.logout()
//		.logoutSuccessUrl("/login")
//		.permitAll();
//		
	}
	
	
	
	
	
	
	
	
}
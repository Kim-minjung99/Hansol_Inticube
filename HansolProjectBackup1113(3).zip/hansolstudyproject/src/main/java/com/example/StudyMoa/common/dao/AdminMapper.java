package com.example.StudyMoa.common.dao;

import org.apache.ibatis.annotations.Mapper;

import com.example.StudyMoa.common.dto.Category;

@Mapper
public interface AdminMapper {

	boolean insertCategory(Category category);

}

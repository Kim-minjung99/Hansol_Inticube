package com.example.StudyMoa.common.controller;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import com.example.StudyMoa.common.dto.Category;
import com.example.StudyMoa.common.service.AdminService;
import com.example.StudyMoa.common.service.CategoryService;
import com.example.StudyMoa.common.utils.UploadFileUtils;

@Controller
public class AdminController {

	@Autowired
	AdminService adminService;
	
	@Autowired
	CategoryService categoryService;
	
	private String uploadPath="C:\\UploadImg";
	
	/*@Resource(name="uploadPath")
	private String uploadPath;
	*/
	
	@RequestMapping(value = "/adminCategory")
	public String adminCategory(){
		
		return "categoryInsertImg";
	}
	
	@RequestMapping(value = "/insertCategory", headers = ("content-type=multipart/*"))
	public String insertCategory(Category category, MultipartFile file) throws Exception{
		
		System.out.println("file 정보 : "+file);
		String imgUploadPath = uploadPath + File.separator;
		System.out.println("imgUploadPath : "+imgUploadPath);
		String ymdPath = UploadFileUtils.calcPath(imgUploadPath);
		System.out.println("ymdPath : "+ymdPath);
		String fileName = null;
		
		if(file != null){
			System.out.println("if문 실행 != null file 정보 : "+fileName);
			fileName = UploadFileUtils.fileUpload(imgUploadPath, file.getOriginalFilename(), file.getBytes(), ymdPath);
			System.out.println("if문 != null file 정보 : "+fileName);
		}else {
			System.out.println("if문 실행 == null file 정보 : "+fileName);
			fileName = uploadPath + File.separator + "images" + File.separator + "none.png";
			System.out.println("if문 == null file 정보 : "+fileName);
		}
		
		
		category.setCategoryThumbImg("C:"+File.separator + "UploadImg" + ymdPath + File.separator + "s" + File.separator + "s_" + fileName);
		category.setCategoryName("투자스터디");
		//System.out.println("insertCategory 종료 : "+category);
		
		
		boolean result = categoryService.insertCategory(category);
		
		
		
		return "categoryInsertImg";
	}
	
	@RequestMapping(value="/selectCategory")
	public String selectCategory(Model model) throws Exception{
		
		int categoryNo = 13;
		
		Category categoryInfo = categoryService.selectCategoryOne(categoryNo);		//카테고리 정보조회
		
		
		model.addAttribute("category", categoryInfo);
		
		return "categorySelect";
	}
	
}

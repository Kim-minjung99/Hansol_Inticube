package com.example.StudyMoa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudyMoaApplicationTests {

	@Test
	void contextLoads() {
	}

}

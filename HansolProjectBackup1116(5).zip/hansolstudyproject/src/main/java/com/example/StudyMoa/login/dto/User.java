package com.example.StudyMoa.login.dto;

import java.util.Collection;
import java.util.Date;

import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Positive;

import org.hibernate.annotations.Entity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User implements UserDetails{
	//DB테이블에 데이터를 집어넣기 위한 객체 선언 [2021.10.29 김민정]
	
	private int userNo;
	
	@NotBlank(message ="이메일은 필수 입력 사항입니다.")
	@Email(message ="이메일 형식에 맞지 않습니다.")
	private String userId;
	
	@NotBlank(message ="이름은 필수 입력 사항입니다.")
	private String userName;
	
	@NotEmpty(message = "전화번호는 필수 입력 사항입니다.")
	
	private String userPhone;
	
	//(?=.*\\W) : 특수문자 필요 , (?=\\S+$) : 공백제거
	@Pattern(regexp="(?=.*[0-9])(?=.*\\W)(?=\\S+$).{4,20}",
            message = "비밀번호는 숫자, 특수기호가 적어도 1개 이상씩 포함된 4자 ~ 20자이어야 합니다.")
	private String userPwd;
	
	private Date instDate;
	private Date updtDate;
	private String status;
	
	@Positive(message = "카테고리는 필수 입력 사항입니다.")
	private int categoryNo;

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return userPwd;
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return userId;
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return false;
	}
	
	
}

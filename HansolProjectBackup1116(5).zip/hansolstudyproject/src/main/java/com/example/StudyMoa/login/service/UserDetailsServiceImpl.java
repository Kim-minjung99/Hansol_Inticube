package com.example.StudyMoa.login.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.example.StudyMoa.login.dao.LoginUserMapper;
import com.example.StudyMoa.login.dao.UserAuthDAO;
import com.example.StudyMoa.login.dto.User;
import com.example.StudyMoa.login.dto.UserInfoDTO;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class UserDetailsServiceImpl implements UserDetailsService{
	
	@Autowired
	private SqlSessionTemplate sqlSession;

	
	@Autowired
	private LoginUserMapper homeMapper;

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	//DB에서 유저정보를 불러온다. Custom한 Userdetails 클래스를 리턴 해주면 된다.(실질적인 로그인코드)
	@Override
	public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
		
		System.out.println("서비스 id : "+userId);
		
		//ArrayList<User> userAuthes = homeMapper.findByUserId(id);
		UserAuthDAO dao = sqlSession.getMapper(UserAuthDAO.class);
		//System.out.println("userAuthes size : "+userAuthes.size());
		User userDetailsDto = dao.selectUserInfo(userId);
		
		if(userDetailsDto == null) {		//user을 찾지 못한경우
			System.out.println("못찾음 : "+ userDetailsDto);
			throw new UsernameNotFoundException("User "+userId+" Not Found!");
		}
		System.out.println("찾음 : "+ userDetailsDto);
		return userDetailsDto;
	}
	
//    //회원가입도중 오류가 날수 있으므로 transactional을 사용합니다 모르면 구글갓에게 물어봅시다
//	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
//	public String InsertUser(ArrayList<User> userVO) throws Exception {
//		userVO.get(0).setUserPwd(bCryptPasswordEncoder.encode(userVO.get(0).getUserPwd()));
//		HashMap map = new HashMap();
//		
//		map.put( "userId", userVO.get(0).getUserId() );
//		// userVO를 homeMapper.signUp으로 전달해주면
//		// 쿼리로 체크한 후 return 값이 1이면 회원가입 가능, 0보다 작으면 회원가입 불가능
//		int flag = homeMapper.userIdCheck(map);
//		System.out.println("flag num : "+flag);
//		
//		if (flag == 0) {
//			userVO.get(0).setStatus("0");
//			int roleNo = homeMapper.findRoleNo(userVO.get(0).getStatus());
//			System.out.println("roleNo : "+roleNo);
//			String id = userVO.get(0).getUserId();
//			homeMapper.insertUser(userVO.get(0));
//
//			return "success";
//		}	 	
//		return "fail";
//	}


}
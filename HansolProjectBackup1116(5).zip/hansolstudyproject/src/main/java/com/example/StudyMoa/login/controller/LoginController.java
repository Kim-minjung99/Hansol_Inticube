package com.example.StudyMoa.login.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.security.core.annotation.AuthenticationPrincipal;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.StudyMoa.common.dto.Category;
import com.example.StudyMoa.common.service.CategoryService;
import com.example.StudyMoa.common.service.StudyService;
import com.example.StudyMoa.login.dto.User;
import com.example.StudyMoa.login.service.LoginUserService;
//import com.example.StudyMoa.login.service.impl.SecurityServiceImpl;



//LoginController : 로그인하여 이동하는 페이지 매핑(2021.10.27 김민정)

@Controller
@RequestMapping("/")
public class LoginController {
	

	
	@Autowired //LoginService대신 insertUserSerivce정의
	LoginUserService loginUserService;
	
	@Autowired
	CategoryService categoryService;
	
	
	
	private final Logger logger = LoggerFactory.getLogger(LoginController.class.getName());			//다음 클래스로 넘어가는 클래스 이름 받아오기
	
	@GetMapping(value="/login")
	public String login(){
			System.out.println("컨트롤러 실행");

		return "login";

		
	}
	

	
	
//	@RequestMapping(value="/joinForm")
//	public String JoinPage(@Valid User user, Errors errors, Model model){ //joinPage() 파라미터 안의 정의된 객체정보가 담겨져있는 User클래스 객체 user에 대해 입력할 수 있는 정보를 찾고
//		
//		System.out.println("유저정보"+ user);
//		
//		if(errors.hasErrors()) { // 아이디 유효성 실패
//			
//			//  회원가입 실패시, 입력 데이터를 유지 주석처리하고 다시 확인하기
//	        //model.addAttribute("user", user);
//	        
//	        
//
//			//맵에 에러메세지 받아서 보여주기
//			Map<String, String> validatorResult = loginUserService.validateHandling(errors);
//			
//			for(String key : validatorResult.keySet()) {
//				
//				model.addAttribute(key, validatorResult.get(key));
//				System.out.println(model.addAttribute(key, validatorResult.get(key)));
//	
//			}
//			return "joinPage";
//			
//		}
//		
//		else { //유효성 에러메세지가 없을때
//			
//			//해쉬맵 사용시 value값 넣을때 형태를 정할땐 상위버전으로 object로 선언해줘야 편하다
//			//Map<String,Object> userConfirmPasswd = new HashMap<>();
//			
//			//해쉬맵에 값넣기
//			//userConfirmPasswd.put("user", user);
//			
//			//System.out.println(userConfirmPasswd.put("user", user).getClass().getName());		//user클래스 해쉬맵에 담아서 형태 확인 com.example.StudyMoa.login.dto.User
//			
//			
//			boolean result = loginUserService.insertUser(user);			//https://www.youtube.com/watch?v=0JHIME7uGOk
//			System.out.println(user);
//			
//			if(result == false) { //회원가입 실패 시
//					return "errorPage"; 
//				}
//				
//				else { //회원가입 성공시
//					return "redirect:/mainPage";
//				}
//			
//		
//			}
//	//return "redirect:/mainPage";
//	
//	}
	@RequestMapping(value="/join")
	public String JoinPage(Model model) throws Exception{
		
		List<Category> categoryList = categoryService.selectCategoryList();			//카테고리 리스트 조회
		model.addAttribute("categoryList", categoryList);							//카테고리 리스트 모델 객체 add
		
		return "joinPage";
	}
	
	@RequestMapping(value="/joinForm", method = {RequestMethod.POST})
	public String JoinPage(@Valid User user,Errors errors, Model model) throws Exception{ //joinPage() 파라미터 안의 정의된 객체정보가 담겨져있는 User클래스 객체 user에 대해 입력할 수 있는 정보를 찾고
		
		List<Category> categoryList = categoryService.selectCategoryList();			//카테고리 리스트 조회
		model.addAttribute("categoryList", categoryList);							//카테고리 리스트 모델 객체 add
		
		
		//사용자 UI에서 입력한 데이터를 해당 모델(model)에 담아서 정보를 찍어준다. [2021.10.29 김민정]
		if(errors.hasErrors()) { // 아이디 유효성 실패 (에러가 있다면)
			
			//맵에 에러메세지 받아서 보여주기
			Map<String, String> validatorResult = loginUserService.validateHandling(errors);
			
			
			//히든처리 필요 만약에 에러가 있다면?(NOT NULL) .HIDE(),, JSP단에서도 SPAN태그에 값이 들어가게 될 것이고, 에러가 없을때 NULL값이 들어오면 .SHOW()
			for(String key : validatorResult.keySet()) {
				
				model.addAttribute(key, validatorResult.get(key));
				//System.out.println(model.addAttribute(key, validatorResult.get(key)));
				System.out.println("모델은 :"+model);
	
			}
			return "joinPage";
			
		}
		
		else { //유효성 성공 (에러메세지가 없을때)
			
			//해쉬맵 사용시 value값 넣을때 형태를 정할땐 상위버전으로 object로 선언해줘야 편하다
			//Map<String,Object> userConfirmPasswd = new HashMap<>();
			
			//해쉬맵에 값넣기
			//userConfirmPasswd.put("user", user);
			
			//System.out.println(userConfirmPasswd.put("user", user).getClass().getName());		//user클래스 해쉬맵에 담아서 형태 확인 com.example.StudyMoa.login.dto.User
			
			
			boolean result = loginUserService.insertUser(user);			//https://www.youtube.com/watch?v=0JHIME7uGOk
			System.out.println(user);
			
			if(result == false) { //회원가입 실패 시
					return "errorPage"; 
				}
				
				else { //회원가입 성공시
					return "redirect:/mainPage";
				}
			
		
			}
	}

	
	
	@RequestMapping(value="/findid")
	public String findid(String findIdName, String findIdPhone){
		
		System.out.println(findIdName);
		System.out.println(findIdPhone);
		
		//boolean resultUserLoginInfo = loginService.userLoginInfo(findIdName, findIdEmail);
		//System.out.println("로그인 찾기를 위한 사용자 조회 :"+resultUserLoginInfo);
		
		return "findId"; // 원래는 loginPage.jsp로 해야되는데 viewResolver를 통해서 생략가능하다. => 생산성 향상 [2021.10.27 김민정]
	
	
	}
	@RequestMapping(value="/findpw")
	public String findpw(String findPwName, String findPwEmail){
		
		System.out.println(findPwName);
		System.out.println(findPwEmail);
		
		return "findPw"; // 원래는 loginPage.jsp로 해야되는데 viewResolver를 통해서 생략가능하다. => 생산성 향상 [2021.10.27 김민정]
	
	
	}
	
	@RequestMapping(value="/loginErrorPage")
	public String loginerrorpage() {
		
		
		return "errorPage";
	}
	
	@RequestMapping(value="/userIdCheck")
	@ResponseBody
	public int userIdCheck(@RequestBody HashMap<String,Object> paramData){
		
		System.out.println("userIdCheck 실행 : "+paramData);
		
		int result = loginUserService.userIdCheck(paramData);
		
		return result;
	}
	
	
	
	
	
}

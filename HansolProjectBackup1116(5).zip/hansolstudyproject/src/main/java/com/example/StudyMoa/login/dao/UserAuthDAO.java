package com.example.StudyMoa.login.dao;

import com.example.StudyMoa.login.dto.User;

public interface UserAuthDAO {

	public User selectUserInfo(String userId);


	
	
}

package com.example.StudyMoa.login.dto;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {
	//DB테이블에 데이터를 집어넣기 위한 객체 선언 [2021.10.29 김민정]
	
	
	
	private int userNo;
	private String userId;
	private String userName;
	private String userPhone;
	private String userPwd;
	private Date instDate;
	private Date updtDate;
	private String status;
	private int categoryNo;
	
	
}

package com.example.StudyMoa.login.service;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import com.example.StudyMoa.login.dto.User;


public interface LoginService {

	boolean insertUser(User user);

	//User selectUserLoginInfo(User user);//로그인하는 사용자의 정보를 데이터베이스로부터 조회하기 위한 기능[2021.10.31 김민정]
	
	String findUserId(User user); // 단일 사용자의 ID값 하나만 사용자에게 전달해준다 => String
	
	String findUserPwd(User user); //단일 사용자의 PWD하나만을 사용자에게 전달해준다.

	UserDetails loadUserByUsername(String userId);
	//selectUserLoginInfo대신에 loadUserByUsername 메소드를 사용하여 db로부터 사용자의 정보를 조회한다.
	//따로 SecurityServiceImpl을 만들어서 UserDetailsService를 상속받았으므로 여기서 명시해줄 필요가 없다.
	

	

}

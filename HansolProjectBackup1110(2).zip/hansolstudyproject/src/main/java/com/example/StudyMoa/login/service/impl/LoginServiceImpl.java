package com.example.StudyMoa.login.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.example.StudyMoa.login.dao.LoginMapper;
import com.example.StudyMoa.login.dto.User;

import com.example.StudyMoa.login.service.LoginService;

@Configuration
@Service
public abstract class LoginServiceImpl implements LoginService {
	
	@Autowired
	LoginMapper loginMapper;
	
	@Autowired
	BCryptPasswordEncoder bCryptPasswordEncoder; //회원가입시 암호화 전환후 비밀번호 저장 [2021.11.07 김민정]
	
	
	@Override
	//@Transactional(propagation = Propagation.REQUIRED, rollbackFor = {Exception.class})
	//트랜잭션(Transaction 이하 트랜잭션)이란, 데이터베이스의 상태를 변화시키기 해서 수행하는 작업의 단위를 뜻한다.
	//해당 트렌젝션 어노테이션으로 큰 트랜잭션의 흐름을 컨트롤 하는 것이라고 생각하면 된다.
	//해당 트렌젝션 설정은 시작된 트렌젝션에 대해서 예외(exception)가 발생하면 데이터베이스에 데이터가 들어가지 않도록 롤백을 해준다. (데이터 삽입시 많이 사용)
	public boolean insertUser(User user) {
		
		user.setUserPwd(bCryptPasswordEncoder.encode(user.getUserPwd()));
		
		
		boolean resultInsertUserInfo = loginMapper.insertUser(user);
		System.out.println(user);
		
		return resultInsertUserInfo;
	}
	
	
	@Override
	public String findUserId(User user) {
		// TODO Auto-generated method stub
		return "findUserId";
	}


	@Override
	public String findUserPwd(User user) {
		// TODO Auto-generated method stub
		return "findUserPwd";
	}


}

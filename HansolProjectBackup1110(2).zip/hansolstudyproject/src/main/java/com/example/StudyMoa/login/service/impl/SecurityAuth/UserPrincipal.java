package com.example.StudyMoa.login.service.impl.SecurityAuth;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.example.StudyMoa.login.dto.User;

public class UserPrincipal implements UserDetails {

	
	private User user;
	
	public UserPrincipal(User user) {
		
		super();
		this.user=user;
	}
	
	//사용자의 등급을 돌려주는 메소드 => getAuthorities
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
//		Collection<GrantedAuthority> userauthcollect = new ArrayList<GrantedAuthority>();
//		userauthcollect.add(()->{return user.getStatus();});
//		return userauthcollect;
		return null;
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return user.getUserPwd();
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return user.getUserName();
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}
	
	
	

}

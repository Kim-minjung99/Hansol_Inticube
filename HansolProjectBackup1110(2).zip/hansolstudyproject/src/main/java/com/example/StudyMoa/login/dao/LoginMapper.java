//Mybatis의 필요한 메소드 정의 적용부분 => loginMapper
//LoginMapper은 Interface로 구현해주는데 굳이 메소드에 대한 정의를 여기 dao에서 해줄 필요가 없기 때문에(메소드에 대한 정의란? ⇒ ex.select * from ...를 해준다.)
//나머지 메소드에 대한 정의는 src/main/resources의 mybatis-mapper의 login-mapper.xml에다가 집어넣어서 정의하면 된다.
//여기에서 mapper은 메소드가 여기있다! 메소드가 있다! 라는 전달의 의미만을 담는다.
package com.example.StudyMoa.login.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import com.example.StudyMoa.login.dto.User;

@Mapper

public interface LoginMapper {

	boolean insertUser(User user); //[회원가입]

	User selectUserLoginInfo(User user);

	User selectByUserId(@Param("userId") String userId); //[로그인] id로 User정보를 담아오기(아이디 조회해서 아이디가 있는 사용자인지 판단)
	
	String findUserId(User user); // 단일 사용자의 ID값 하나만 사용자에게 전달해준다 => String
	
	String findUserPwd(User user); //단일 사용자의 PWD하나만을 사용자에게 전달해준다.
	

	//ArrayList<User> findByUserId(@Param("userId") String userId); //Param 어노테이션으로 userDto에 userId로 접근한다. 설명 명시는 주석처럼 우리한테 설명하는 것이 아니라 컴퓨터에 명시하여 설명해 주는 의미이다.
	
	
	

	
}

package com.example.StudyMoa.login.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import com.example.StudyMoa.login.dao.LoginMapper;
import com.example.StudyMoa.login.dto.User;
import com.example.StudyMoa.login.service.impl.SecurityAuth.UserPrincipal;

@Service
public class SecurityServiceImpl implements UserDetailsService{ //기존의 로그인 서비스impl단으로부터 독립해서 나와서 userDetailsService를 상속받아쓴다  

	@Autowired
	private LoginMapper loginMapper;
	
	public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException { 
		//userDetails 인터페이스를 꼭 구현해야 한다. (userDetails는 인터페이스이다. 결론 : loadUserByUsername(메소드)>>UserDetails(인터페이스)>>UserPrincipalDto)
		//WHY? : 이 loadUserByUsername 메소드가 userDetails를 리턴하기 때문이다.
		//user에다가 userDetails정보를 받아오고싶은데...
		
		//User user=new User();
		
		User user = loginMapper.selectByUserId(userId);
		
		
		
		if(user == null) {
			throw new UsernameNotFoundException(userId+"is not found");
		}
		
		return new UserPrincipal(user); //user형태로 돌려받은 resultUserLoginInfo는 이후 userDetailsService로부터 메소드가 호출되어 리턴값으로 돌려받은 userDetails값을
		//user class와 userDetails 인터페이스를 상속받은 userPrincipal class에 저장시켜서 사용한다.
	}
	

	
	

}

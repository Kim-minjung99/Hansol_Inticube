package com.example.StudyMoa.mypage.dao;

public class MyPageMapper {
	


}

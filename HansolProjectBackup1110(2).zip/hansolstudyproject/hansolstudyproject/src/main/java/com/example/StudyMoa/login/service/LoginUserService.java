package com.example.StudyMoa.login.service;

import java.util.Map;

import org.springframework.validation.Errors;

import com.example.StudyMoa.login.dto.User;

public interface LoginUserService {

	boolean insertUser(User user);
	
	String findUserId(User user); // 단일 사용자의 ID값 하나만 사용자에게 전달해준다 => String
	
	String findUserPwd(User user); //단일 사용자의 PWD하나만을 사용자에게 전달해준다.

	Map<String, String> validateHandling(Errors errors);


}

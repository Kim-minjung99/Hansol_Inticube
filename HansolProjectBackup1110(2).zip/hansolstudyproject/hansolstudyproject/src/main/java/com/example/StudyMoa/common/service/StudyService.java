package com.example.StudyMoa.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.example.StudyMoa.common.dto.Paging;
import com.example.StudyMoa.common.dto.Study;

public interface StudyService {
	
	List<Study> selectStudyList(Map<String, Object> map) throws Exception;

	List<Study> selectStudyList(int categoryNo) throws Exception;

	int selectStudyCount(Map<String, Object> map) throws Exception;

	Study selectStudyOne(Map<String, Object> map) throws Exception;

	boolean updateStudySNow(int sNow);

	boolean updateStudySEndDate(HashMap<String, Object> reviewParam);

}

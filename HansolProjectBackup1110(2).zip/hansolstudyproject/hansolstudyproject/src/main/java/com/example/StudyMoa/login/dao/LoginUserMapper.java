package com.example.StudyMoa.login.dao;

import org.apache.ibatis.annotations.Mapper;

import com.example.StudyMoa.login.dto.User;

@Mapper
public interface LoginUserMapper {

	boolean insertUser(User user);
	
	String findUserId(User user);
	
	String findUserPwd(User user);

}
